# README #

### Who has adapted this model? ###

This model has been adapted to a simulation model by Alberto Ezquerro.
email: aezquerro@theconstructsim.com

### What does it contain? ###

It contains a chair.

### Where does this model run? ###

This model has been tested in Gazebo 6.

### How to launch a test to see the model? ###

1. Put the folder in your catkin_ws/src folder.

2. Compile the package typing the following from your catkin_ws folder.

catkin_make

3. Type the following command in your console:

roslaunch chair1_gazebo chair1.launch 
