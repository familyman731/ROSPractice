^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tiago_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2015-12-01)
------------------
* add grasping demo
* Contributors: Jordi Pages

0.0.1 (2015-09-07)
------------------
* Update maintainer email
* Update package xmls
* First tiago release
* Contributors: Bence Magyar
