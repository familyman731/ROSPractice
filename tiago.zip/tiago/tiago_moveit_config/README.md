# tiago_moveit_config

For more information please refer to http://wiki.ros.org/Robots/TIAGo

![Image of TIAGo](http://wiki.ros.org/Robots/TIAGo?action=AttachFile&do=get&target=tiago.png)
