^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package play_motion_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.0 (2014-04-23)
------------------
* Add service call to query available motions.
* Make planning optional. Deprecate reach_time.
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.3.5 (2014-02-25)
------------------

0.3.4 (2014-02-24)
------------------

0.3.3 (2014-02-20)
------------------
* separate messages from play_motion into new package play_motion_msgs

