^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package head_action
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2015-07-23)
------------------
* Add head_action
* Contributors: Bence Magyar, Sammy Pfeiffer
