^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tiago_robot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2015-12-01)
------------------
* Fix inertial matrices of gripper
* Add movements for the Gazebo grasping demo
* Contributors: Jordi Pages

0.0.1 (2015-08-03)
------------------
* First tiago release
* Contributors: Bence Magyar
