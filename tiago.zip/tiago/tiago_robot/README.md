# tiago_robot

For more information please refer to http://wiki.ros.org/Robots/TIAGo

For technical questions please write to tiago-support@pal-robotics.com

![Image of TIAGo](http://wiki.ros.org/Robots/TIAGo?action=AttachFile&do=get&target=tiago.png)
